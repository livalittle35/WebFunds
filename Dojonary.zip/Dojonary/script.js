function changeText(element){
    document.getElementById('btn1').innerTEXT="Logout"
    element.innerText="Logout"
    
    // console.log("You clicked me", element.innerText)
}

// alert("I'm working")

function hide(element){
    document.getElementById('btn3').hide
    element.remove();
}

// function alert(){
//     document.getElementById('btn2').alert="This page says Ninja was liked  Ok"
//     element.alert="This page says Ninja was liked  Ok"
// }

// function alert(element){
//     document.getElementById('btn2').alert="This page says\Ninja was liked\Ok"
//     element.alert="This page says\Ninja was liked\Ok"
// }